<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Portfolio</title>
    <meta name="description" content="Welcome to the portfolio of Md Sahabul, a professional web designer and developer specializing in high-quality, responsive websites.">
    <meta name="keywords" content="web design, web development, portfolio, Md Sahabul, responsive design, freelance developer">
    <meta name="author" content="Md Sahabul">
    <!-- Bootstrap CSS (should load first) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Your custom CSS (should load after Bootstrap) -->
    <link rel="stylesheet" href="/portfolio/assets/css/style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- jQuery and Bootstrap JS (optional, these can stay here) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

</head>
<body>
<script src="https://www.google.com/recaptcha/api.js?render=6LeIQjMqAAAAAP3hoe8qZYZryT9z_ZXouU-AkbFP"></script>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/portfolio/index"><strong>Sahabul.</strong></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="/portfolio/index">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#About">About</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#Services">Services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#Portfolio">Portfolio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#Skills">Skills</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#Reviews">Reviews</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#Contact">Contact</a>
                            </li>
                            <?php
                            // Start session if it's not already active
                            if (session_status() === PHP_SESSION_NONE) {
                                session_start();
                            }

                            // Check if user is logged in
                            if (isset($_SESSION['user_id']) && $_SESSION['user_id'] === 'devsahabul@gmail.com') {
                                echo '<li><a href="/portfolio/admin/add_project.php">Add Project</a></li>';
                                echo '<li><a href="/portfolio/admin/logout.php">Logout</a></li>';
                            } else {
                                echo '<li><a href="/portfolio/admin/login.php"></a></li>'; // Redirect to login
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </nav>

    <div class="container">
        <!-- Main content goes here -->
</body>
</html>
