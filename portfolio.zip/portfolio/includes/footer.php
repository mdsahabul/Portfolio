</div> <!-- End of container -->
<footer class="text-center mt-5">
                <div class="footer-site-logo">
                     <a class="navbar-brand" href="index.php"><strong>Sahabul.</strong></a>
                </div>
                
                <div class="social py-3">
                    <nav>
                        <ul class="list-inline text-center m-0">
                            <li class="list-inline-item">
                                <a href="https://www.facebook.com/devsahabul" target="_blank" class="text-secondary p-2">Facebook</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://wa.me/8801518986439?text= Hello wanna inquire my service details, thanks" target="_blank" class="text-secondary p-2">Whatsapp</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://twitter.com/devsahabul" target="_blank" class="text-secondary p-2">Twitter</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://www.instagram.com/sahabul.123" target="_blank" class="text-secondary p-2">Instagram</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://dribbble.com/mdsahabul" target="_blank" class="text-secondary p-2">Dribble</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://www.behance.net/sahabul" target="_blank" class="text-secondary p-2">Behance</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://www.pinterest.com/sahabulmd/" target="_blank" class="text-secondary p-2">Pinterest</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://www.linkedin.com/in/mdsahabul" target="_blank" class="text-secondary p-2">LinkedIn</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="https://www.youtube.com/@Md.Sahabul-dev" target="_blank" class="text-secondary p-2">Youtube</a>
                            </li>
                        </ul>
                    </nav>
                </div>




                <div class="copyright">
                    <p class="site-copyright">
                
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright ©
                        <script>
                          document.write(new Date().getFullYear());
                        </script> All rights reserved | This template is made<i class="icon-heart" aria-hidden="true"></i> by ❤<a href="https://github.com/mdsahabul" target="_blank">Md Sahabul</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                      
                      </p>
                </div>
            </footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
