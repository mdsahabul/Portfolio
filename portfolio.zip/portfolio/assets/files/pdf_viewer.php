<?php include '../../includes/header.php';?>
<?php include '../../db.php'; ?>

<div class="container-fluid">
    <h2 class="mt-4 text-center my-5">My CV</h2>
    <div class="ratio ratio-4x3">
        <object data="CV.pdf" type="application/pdf" width="100%" height="100%">
            <p>Your browser does not support PDFs. 
               <a href="CV.pdf">Download the PDF</a>.</p>
        </object>
    </div>
</div>

<?php include '../../includes/footer.php';?>
