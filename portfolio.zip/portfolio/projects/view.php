<?php include '../includes/header.php'; ?>
<?php include '../db.php'; ?>

<?php
$id = $_GET['id'];
$sql = "SELECT * FROM projects WHERE id = $id";
$result = $conn->query($sql);
$project = $result->fetch_assoc();
?>

<div class="container mt-5">
    <h1><?php echo $project['title']; ?></h1>
    <img src="../assets/images/<?php echo $project['image']; ?>" class="img-fluid" alt="<?php echo $project['title']; ?>">
    <p><?php echo $project['description']; ?></p>
    <a href="../index.php" class="btn btn-secondary">Back to Home</a>
</div>

<?php include '../includes/footer.php'; ?>
