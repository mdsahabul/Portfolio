<?php
session_start(); // Start the session to refresh it
// The script doesn't need to do anything else; just running it will keep the session alive
?>
